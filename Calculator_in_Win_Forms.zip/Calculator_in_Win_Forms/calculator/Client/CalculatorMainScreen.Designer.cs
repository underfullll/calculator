﻿namespace calculator
{
    partial class CalculatorMainScreen
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.EraseCharButton = new System.Windows.Forms.Button();
            this.InputTextBox = new System.Windows.Forms.TextBox();
            this.OutputTextBox = new System.Windows.Forms.TextBox();
            this.ClearAllButton = new System.Windows.Forms.Button();
            this.OperatorPow2Button = new System.Windows.Forms.Button();
            this.OperatorPlusButton = new System.Windows.Forms.Button();
            this.OperatorMinusButton = new System.Windows.Forms.Button();
            this.OperatorMultButton = new System.Windows.Forms.Button();
            this.OperatorDivButton = new System.Windows.Forms.Button();
            this.OperatorEqButton = new System.Windows.Forms.Button();
            this.OperatorBracketEndButton = new System.Windows.Forms.Button();
            this.Number3Button = new System.Windows.Forms.Button();
            this.Number6Button = new System.Windows.Forms.Button();
            this.Number9Button = new System.Windows.Forms.Button();
            this.Number8Button = new System.Windows.Forms.Button();
            this.Number7Button = new System.Windows.Forms.Button();
            this.Number4Button = new System.Windows.Forms.Button();
            this.OperatorBracketStartButton = new System.Windows.Forms.Button();
            this.Number0Button = new System.Windows.Forms.Button();
            this.Number2Button = new System.Windows.Forms.Button();
            this.Number1Button = new System.Windows.Forms.Button();
            this.Number5Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // EraseCharButton
            // 
            this.EraseCharButton.Location = new System.Drawing.Point(93, 71);
            this.EraseCharButton.Name = "EraseCharButton";
            this.EraseCharButton.Size = new System.Drawing.Size(75, 75);
            this.EraseCharButton.TabIndex = 0;
            this.EraseCharButton.Text = "<";
            this.EraseCharButton.UseVisualStyleBackColor = true;
            this.EraseCharButton.Click += new System.EventHandler(this.EraseCharButton_Click);
            // 
            // InputTextBox
            // 
            this.InputTextBox.Location = new System.Drawing.Point(12, 12);
            this.InputTextBox.Multiline = true;
            this.InputTextBox.Name = "InputTextBox";
            this.InputTextBox.Size = new System.Drawing.Size(237, 53);
            this.InputTextBox.TabIndex = 1;
            this.InputTextBox.TextChanged += new System.EventHandler(this.InputTextBox_TextChanged);
            // 
            // OutputTextBox
            // 
            this.OutputTextBox.Location = new System.Drawing.Point(255, 12);
            this.OutputTextBox.Multiline = true;
            this.OutputTextBox.Name = "OutputTextBox";
            this.OutputTextBox.Size = new System.Drawing.Size(75, 53);
            this.OutputTextBox.TabIndex = 2;
            this.OutputTextBox.TextChanged += new System.EventHandler(this.OutputTextBox_TextChanged);
            // 
            // ClearAllButton
            // 
            this.ClearAllButton.Location = new System.Drawing.Point(12, 71);
            this.ClearAllButton.Name = "ClearAllButton";
            this.ClearAllButton.Size = new System.Drawing.Size(75, 75);
            this.ClearAllButton.TabIndex = 3;
            this.ClearAllButton.Text = "CL";
            this.ClearAllButton.UseVisualStyleBackColor = true;
            this.ClearAllButton.Click += new System.EventHandler(this.ClearAllButton_Click);
            // 
            // OperatorPow2Button
            // 
            this.OperatorPow2Button.Location = new System.Drawing.Point(174, 71);
            this.OperatorPow2Button.Name = "OperatorPow2Button";
            this.OperatorPow2Button.Size = new System.Drawing.Size(75, 75);
            this.OperatorPow2Button.TabIndex = 4;
            this.OperatorPow2Button.Text = "^";
            this.OperatorPow2Button.UseVisualStyleBackColor = true;
            this.OperatorPow2Button.Click += new System.EventHandler(this.OperatorPow2Button_Click);
            // 
            // OperatorPlusButton
            // 
            this.OperatorPlusButton.Location = new System.Drawing.Point(255, 71);
            this.OperatorPlusButton.Name = "OperatorPlusButton";
            this.OperatorPlusButton.Size = new System.Drawing.Size(75, 75);
            this.OperatorPlusButton.TabIndex = 5;
            this.OperatorPlusButton.Text = "+";
            this.OperatorPlusButton.UseVisualStyleBackColor = true;
            this.OperatorPlusButton.Click += new System.EventHandler(this.OperatorPlusButton_Click);
            // 
            // OperatorMinusButton
            // 
            this.OperatorMinusButton.Location = new System.Drawing.Point(255, 152);
            this.OperatorMinusButton.Name = "OperatorMinusButton";
            this.OperatorMinusButton.Size = new System.Drawing.Size(75, 75);
            this.OperatorMinusButton.TabIndex = 6;
            this.OperatorMinusButton.Text = "-";
            this.OperatorMinusButton.UseVisualStyleBackColor = true;
            this.OperatorMinusButton.Click += new System.EventHandler(this.OperatorMinusButton_Click);
            // 
            // OperatorMultButton
            // 
            this.OperatorMultButton.Location = new System.Drawing.Point(255, 233);
            this.OperatorMultButton.Name = "OperatorMultButton";
            this.OperatorMultButton.Size = new System.Drawing.Size(75, 75);
            this.OperatorMultButton.TabIndex = 7;
            this.OperatorMultButton.Text = "*";
            this.OperatorMultButton.UseVisualStyleBackColor = true;
            this.OperatorMultButton.Click += new System.EventHandler(this.OperatorMultButton_Click);
            // 
            // OperatorDivButton
            // 
            this.OperatorDivButton.Location = new System.Drawing.Point(255, 314);
            this.OperatorDivButton.Name = "OperatorDivButton";
            this.OperatorDivButton.Size = new System.Drawing.Size(75, 75);
            this.OperatorDivButton.TabIndex = 8;
            this.OperatorDivButton.Text = "/";
            this.OperatorDivButton.UseVisualStyleBackColor = true;
            this.OperatorDivButton.Click += new System.EventHandler(this.OperatorDivButton_Click);
            // 
            // OperatorEqButton
            // 
            this.OperatorEqButton.Location = new System.Drawing.Point(255, 395);
            this.OperatorEqButton.Name = "OperatorEqButton";
            this.OperatorEqButton.Size = new System.Drawing.Size(75, 75);
            this.OperatorEqButton.TabIndex = 9;
            this.OperatorEqButton.Text = "=";
            this.OperatorEqButton.UseVisualStyleBackColor = true;
            this.OperatorEqButton.Click += new System.EventHandler(this.OperatorEqButton_Click);
            // 
            // OperatorBracketEndButton
            // 
            this.OperatorBracketEndButton.Location = new System.Drawing.Point(174, 395);
            this.OperatorBracketEndButton.Name = "OperatorBracketEndButton";
            this.OperatorBracketEndButton.Size = new System.Drawing.Size(75, 75);
            this.OperatorBracketEndButton.TabIndex = 10;
            this.OperatorBracketEndButton.Text = ")";
            this.OperatorBracketEndButton.UseVisualStyleBackColor = true;
            this.OperatorBracketEndButton.Click += new System.EventHandler(this.OperatorBracketEndButton_Click);
            // 
            // Number3Button
            // 
            this.Number3Button.Location = new System.Drawing.Point(174, 314);
            this.Number3Button.Name = "Number3Button";
            this.Number3Button.Size = new System.Drawing.Size(75, 75);
            this.Number3Button.TabIndex = 11;
            this.Number3Button.Text = "3";
            this.Number3Button.UseVisualStyleBackColor = true;
            this.Number3Button.Click += new System.EventHandler(this.Number3Button_Click);
            // 
            // Number6Button
            // 
            this.Number6Button.Location = new System.Drawing.Point(174, 233);
            this.Number6Button.Name = "Number6Button";
            this.Number6Button.Size = new System.Drawing.Size(75, 75);
            this.Number6Button.TabIndex = 12;
            this.Number6Button.Text = "6";
            this.Number6Button.UseVisualStyleBackColor = true;
            this.Number6Button.Click += new System.EventHandler(this.Number6Button_Click);
            // 
            // Number9Button
            // 
            this.Number9Button.Location = new System.Drawing.Point(174, 152);
            this.Number9Button.Name = "Number9Button";
            this.Number9Button.Size = new System.Drawing.Size(75, 75);
            this.Number9Button.TabIndex = 13;
            this.Number9Button.Text = "9";
            this.Number9Button.UseVisualStyleBackColor = true;
            this.Number9Button.Click += new System.EventHandler(this.Number9Button_Click);
            // 
            // Number8Button
            // 
            this.Number8Button.Location = new System.Drawing.Point(93, 152);
            this.Number8Button.Name = "Number8Button";
            this.Number8Button.Size = new System.Drawing.Size(75, 75);
            this.Number8Button.TabIndex = 14;
            this.Number8Button.Text = "8";
            this.Number8Button.UseVisualStyleBackColor = true;
            this.Number8Button.Click += new System.EventHandler(this.Number8Button_Click);
            // 
            // Number7Button
            // 
            this.Number7Button.Location = new System.Drawing.Point(12, 152);
            this.Number7Button.Name = "Number7Button";
            this.Number7Button.Size = new System.Drawing.Size(75, 75);
            this.Number7Button.TabIndex = 15;
            this.Number7Button.Text = "7";
            this.Number7Button.UseVisualStyleBackColor = true;
            this.Number7Button.Click += new System.EventHandler(this.Number7Button_Click);
            // 
            // Number4Button
            // 
            this.Number4Button.Location = new System.Drawing.Point(12, 233);
            this.Number4Button.Name = "Number4Button";
            this.Number4Button.Size = new System.Drawing.Size(75, 75);
            this.Number4Button.TabIndex = 16;
            this.Number4Button.Text = "4";
            this.Number4Button.UseVisualStyleBackColor = true;
            this.Number4Button.Click += new System.EventHandler(this.Number4Button_Click);
            // 
            // OperatorBracketStartButton
            // 
            this.OperatorBracketStartButton.Location = new System.Drawing.Point(93, 395);
            this.OperatorBracketStartButton.Name = "OperatorBracketStartButton";
            this.OperatorBracketStartButton.Size = new System.Drawing.Size(75, 75);
            this.OperatorBracketStartButton.TabIndex = 17;
            this.OperatorBracketStartButton.Text = "(";
            this.OperatorBracketStartButton.UseVisualStyleBackColor = true;
            this.OperatorBracketStartButton.Click += new System.EventHandler(this.OperatorBracketStartButton_Click);
            // 
            // Number0Button
            // 
            this.Number0Button.Location = new System.Drawing.Point(12, 395);
            this.Number0Button.Name = "Number0Button";
            this.Number0Button.Size = new System.Drawing.Size(75, 75);
            this.Number0Button.TabIndex = 18;
            this.Number0Button.Text = "0";
            this.Number0Button.UseVisualStyleBackColor = true;
            this.Number0Button.Click += new System.EventHandler(this.Number0Button_Click);
            // 
            // Number2Button
            // 
            this.Number2Button.Location = new System.Drawing.Point(93, 314);
            this.Number2Button.Name = "Number2Button";
            this.Number2Button.Size = new System.Drawing.Size(75, 75);
            this.Number2Button.TabIndex = 19;
            this.Number2Button.Text = "2";
            this.Number2Button.UseVisualStyleBackColor = true;
            this.Number2Button.Click += new System.EventHandler(this.Number2Button_Click);
            // 
            // Number1Button
            // 
            this.Number1Button.Location = new System.Drawing.Point(12, 314);
            this.Number1Button.Name = "Number1Button";
            this.Number1Button.Size = new System.Drawing.Size(75, 75);
            this.Number1Button.TabIndex = 20;
            this.Number1Button.Text = "1";
            this.Number1Button.UseVisualStyleBackColor = true;
            this.Number1Button.Click += new System.EventHandler(this.Number1Button_Click);
            // 
            // Number5Button
            // 
            this.Number5Button.Location = new System.Drawing.Point(93, 233);
            this.Number5Button.Name = "Number5Button";
            this.Number5Button.Size = new System.Drawing.Size(75, 75);
            this.Number5Button.TabIndex = 21;
            this.Number5Button.Text = "5";
            this.Number5Button.UseVisualStyleBackColor = true;
            this.Number5Button.Click += new System.EventHandler(this.Number5Button_Click);
            // 
            // CalculatorMainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 493);
            this.Controls.Add(this.Number5Button);
            this.Controls.Add(this.Number1Button);
            this.Controls.Add(this.Number2Button);
            this.Controls.Add(this.Number0Button);
            this.Controls.Add(this.OperatorBracketStartButton);
            this.Controls.Add(this.Number4Button);
            this.Controls.Add(this.Number7Button);
            this.Controls.Add(this.Number8Button);
            this.Controls.Add(this.Number9Button);
            this.Controls.Add(this.Number6Button);
            this.Controls.Add(this.Number3Button);
            this.Controls.Add(this.OperatorBracketEndButton);
            this.Controls.Add(this.OperatorEqButton);
            this.Controls.Add(this.OperatorDivButton);
            this.Controls.Add(this.OperatorMultButton);
            this.Controls.Add(this.OperatorMinusButton);
            this.Controls.Add(this.OperatorPlusButton);
            this.Controls.Add(this.OperatorPow2Button);
            this.Controls.Add(this.ClearAllButton);
            this.Controls.Add(this.OutputTextBox);
            this.Controls.Add(this.InputTextBox);
            this.Controls.Add(this.EraseCharButton);
            this.Name = "CalculatorMainScreen";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EraseCharButton;
        private System.Windows.Forms.TextBox InputTextBox;
        private System.Windows.Forms.TextBox OutputTextBox;
        private System.Windows.Forms.Button ClearAllButton;
        private System.Windows.Forms.Button OperatorPow2Button;
        private System.Windows.Forms.Button OperatorPlusButton;
        private System.Windows.Forms.Button OperatorMinusButton;
        private System.Windows.Forms.Button OperatorMultButton;
        private System.Windows.Forms.Button OperatorDivButton;
        private System.Windows.Forms.Button OperatorEqButton;
        private System.Windows.Forms.Button OperatorBracketEndButton;
        private System.Windows.Forms.Button Number3Button;
        private System.Windows.Forms.Button Number6Button;
        private System.Windows.Forms.Button Number9Button;
        private System.Windows.Forms.Button Number8Button;
        private System.Windows.Forms.Button Number7Button;
        private System.Windows.Forms.Button Number4Button;
        private System.Windows.Forms.Button OperatorBracketStartButton;
        private System.Windows.Forms.Button Number0Button;
        private System.Windows.Forms.Button Number2Button;
        private System.Windows.Forms.Button Number1Button;
        private System.Windows.Forms.Button Number5Button;
    }
}

